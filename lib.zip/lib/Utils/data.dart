class CustomData {
  const CustomData({this.name = '[your name]'});

  final String name;
}
